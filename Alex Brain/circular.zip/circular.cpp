#include "circular.h"
#include <iostream>
using namespace std;

#define array_size 100
circular::circular()
{
    front_pointer = 0;
    back_pointer = 0;
}

void circular::buffer_clear() //clear the entire memory address by resetting the pointer, we do not erase
{
    front_pointer = 0;
    back_pointer = 0;
}

void circular::write_buffer(void* info, int size)
{
    int temp_buffer[array_size]; //create a temp buffer to hold stuff here first
    int max_allowed;

    //first, calculate how much leeway we have to implement the array
    if (front_pointer < back_pointer) //the front pointer is behind the back pointer, calculate how much space left
    {
        max_allowed = (back_pointer - front_pointer);

    }

    else
    {
        max_allowed = array_size - (front_pointer - back_pointer);
    }

    if ((size / sizeof(int)) >= max_allowed) //we cannot store stuff here, too little information
    {
        cout << "Too much information" << endl;
        return;
    }

    else
    {
        memcpy(temp_buffer, info, size);
        for (int i = 0; i < (size / sizeof(int)); i++)
        {
            memcpy(&global_buffer[front_pointer], &temp_buffer[i], sizeof(int));
            front_pointer = (front_pointer == array_size - 1) ? 0 : front_pointer + 1;
        }


    }
}

void circular::read_buffer(void* storage, int size)
{
    int amount;
    int max_allowed;
    int temp_buffer[array_size];

    amount = size / sizeof(int);

    //first, calculate how much stuff there is to read from
    if (back_pointer <= front_pointer) //keep moving forward till reach front pointer
    {
        max_allowed = front_pointer - back_pointer;
    }
    else
    {
        max_allowed = array_size - (back_pointer - front_pointer);
    }

    if (amount > max_allowed)
    {
        cout << "Too little information" << endl;
        return;
    }

    else
    {
        for (int i = 0; i < amount; i++)
        {
            memcpy(&temp_buffer[i], &global_buffer[back_pointer], sizeof(int));
            back_pointer = (back_pointer == array_size - 1) ? 0 : back_pointer + 1;
        }

        memcpy(storage, temp_buffer, size);
        return;
    }
}