#pragma once


class circular
{
private:
    int global_buffer[100]; //global buffer to store our stuff
    int front_pointer;
    int back_pointer;

public:
    circular();
    void write_buffer(void* info, int size); //give it the memory location of the information and it will copy there
    void read_buffer(void* storage, int size); //read the current buffer and store information there
    void buffer_clear();

};